package com.example.MongoDB.SpringMongoDBApplication.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "AddressDB")

public class Address {
	@Id
    private long address_id;
	private String street;
	private String city;
	private String state;
	
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name="STUDENT_ID") private Student student;
	 */


	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	/*
	 * public Student getStudent() { return student; } public void
	 * setStudent(Student student) { this.student = student; }
	 */
	
	public long getAddress_id() {
		return address_id;
	}
	public void setAddress_id(long address_id) {
		this.address_id = address_id;
	}
	
	public Address() {
		super();
	}
	
	
}
