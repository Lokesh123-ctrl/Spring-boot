package com.example.MongoDB.SpringMongoDBApplication.service;

import java.util.List;
import com.example.MongoDB.SpringMongoDBApplication.model.Student;

public interface StudentService {
	
   public  Student createStudent(Student student);

   public Student updateStudent(Student student);

   public List < Student > getAllStudent();

    public Student getStudentById(long studentId);

    public void deleteStudent(long id);
;
}
