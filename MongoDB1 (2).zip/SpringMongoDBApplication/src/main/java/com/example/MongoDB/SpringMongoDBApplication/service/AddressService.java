package com.example.MongoDB.SpringMongoDBApplication.service;

import java.util.List;

import com.example.MongoDB.SpringMongoDBApplication.model.Address;

public interface AddressService {
	public Address saveAddress(Address address);
	
	//To update Address
	
	public Address updateAddress(Address address);
	
	// To fetch all addresss from database
	
	public List<Address> findAllAddresss();
	
	// To delete address
	public void deleteAddress(int id);

}
