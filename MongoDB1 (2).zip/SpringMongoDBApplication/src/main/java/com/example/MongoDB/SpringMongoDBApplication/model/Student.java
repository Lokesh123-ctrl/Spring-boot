package com.example.MongoDB.SpringMongoDBApplication.model;




import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "StudentDB")
public class Student {

    @Id
    private long id;


    @Indexed(unique = true)
    private String name;
    private String description;
    
    @OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
    private List<Address> address; 

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", description=" + description + ", address=" + address + "]";
	}
    
    
}




