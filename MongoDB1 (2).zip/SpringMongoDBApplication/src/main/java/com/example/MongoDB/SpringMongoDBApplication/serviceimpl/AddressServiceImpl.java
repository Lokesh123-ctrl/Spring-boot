package com.example.MongoDB.SpringMongoDBApplication.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MongoDB.SpringMongoDBApplication.model.Address;
import com.example.MongoDB.SpringMongoDBApplication.repository.AddressRepository;
import com.example.MongoDB.SpringMongoDBApplication.service.AddressService;


	@Service
	public class AddressServiceImpl implements AddressService{
	@Autowired
	private AddressRepository addressRepo;
	@Override
	public Address saveAddress(Address student) {
		return addressRepo.save(student);
	}
	@Override
	public Address updateAddress(Address student) {
		
		return addressRepo.save(student);
	}
	@Override
	public List<Address> findAllAddresss() {
		// It returns a list so casting is needed
		return (List<Address>) addressRepo.findAll();
		
	}
	@Override
	public void deleteAddress(int id) {
		// To delete student
		addressRepo.deleteById(id);
	}
	
}

