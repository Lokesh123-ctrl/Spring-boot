package com.example.MongoDB.SpringMongoDBApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
